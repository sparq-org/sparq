/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const contribute: (a: number, b: number) => [number, number, number, number];
export const finish: (a: number, b: number) => [number, number, number, number];
export const generateKeys: (a: number, b: number) => [number, number, number, number];
export const newSession: (a: number, b: number) => [number, number, number, number];
export const receiveAndPartial: (a: number, b: number) => [number, number, number, number];
export const simulateSession: (a: number, b: number, c: number, d: number) => [number, number, number, number];
export const verifyOutcome: (a: number, b: number) => [number, number, number, number];
export const __wbindgen_malloc: (a: number, b: number) => number;
export const __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
export const __wbindgen_exn_store: (a: number) => void;
export const __externref_table_alloc: () => number;
export const __wbindgen_externrefs: WebAssembly.Table;
export const __externref_table_dealloc: (a: number) => void;
export const __wbindgen_free: (a: number, b: number, c: number) => void;
export const __wbindgen_start: () => void;
