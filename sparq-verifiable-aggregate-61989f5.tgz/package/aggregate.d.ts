/* tslint:disable */
/* eslint-disable */

export function contribute(json: string): string;

export function finish(json: string): string;

export function generateKeys(seed?: string | null): string;

export function newSession(json: string): string;

export function receiveAndPartial(json: string): string;

/**
 * Single-process simulation with private transcript; each array entry is a party-input JSON string.
 */
export function simulateSession(params_json: string, party_inputs_json: string[]): string;

export function verifyOutcome(json: string): string;
export type * from './wire';
